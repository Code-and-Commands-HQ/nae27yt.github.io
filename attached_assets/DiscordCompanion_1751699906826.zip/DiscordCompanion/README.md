# Discord Bot with Slash Commands

A custom Discord bot featuring slash commands for message echoing, embed creation, and direct messaging functionality.

## Features

### Core Commands
- **`/say [message]`** - Make the bot echo any message you want
- **`/embed [title] [description] [color]`** - Create custom embeds with optional colors
- **`/dm [user] [message]`** - Send direct messages to users through the bot

### Utility Commands
- **`/help`** - Get help with all bot commands and their usage
- **`/ping`** - Check bot latency and response time
- **`/serverinfo`** - Get detailed information about the current server
- **`/userinfo [user]`** - Get information about any user (leave blank for yourself)

### Role Management Commands
- **`/protect-role [role]`** - Make a role protected (only assignable via bot)
- **`/assign-role [user] [role]`** - Assign a protected role to a user
- **`/unprotect-role [role]`** - Remove protection from a role
- **`/list-protected-roles`** - List all protected roles in this server

**Role Protection System:** Protected roles can only be assigned using the `/assign-role` command. If someone tries to manually add a protected role, it will be automatically removed and the user will be notified.

## Setup

### Prerequisites

- Python 3.8 or higher
- discord.py library
- A Discord bot token

### Installation

1. Install the required dependencies:
```bash
pip install discord.py python-dotenv
