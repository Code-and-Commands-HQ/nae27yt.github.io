"""
General Commands Cog
Contains all general slash commands for the Discord bot
"""

import discord
from discord.ext import commands
from discord import app_commands
import logging
from typing import Optional
from bot_config import BotConfig
from utils.embed_utils import create_embed, create_error_embed, create_success_embed, validate_embed_content
from utils.validation import validate_message_content, validate_mention_input, sanitize_message, can_dm_user
import datetime
import json

logger = logging.getLogger(__name__)

class GeneralCommands(commands.Cog):
    """General commands cog with slash commands"""
    
    def __init__(self, bot):
        self.bot = bot
        self.later_work_file = "later_work.json"
        self.load_later_work()
    
    def load_later_work(self):
        """Load later work items from file"""
        try:
            with open(self.later_work_file, 'r') as f:
                self.later_work = json.load(f)
        except FileNotFoundError:
            self.later_work = {}
    
    def save_later_work(self):
        """Save later work items to file"""
        with open(self.later_work_file, 'w') as f:
            json.dump(self.later_work, f, indent=2)
    
    @app_commands.command(name="say", description="Make the bot say something")
    @app_commands.describe(message="The message you want the bot to say")
    @app_commands.checks.cooldown(BotConfig.MAX_USES_PER_COOLDOWN, BotConfig.SAY_COOLDOWN)
    async def say_command(self, interaction: discord.Interaction, message: str):
        """
        Say command - echoes user input back to the channel
        
        Args:
            interaction: Discord interaction object
            message: Message to echo
        """
        try:
            # Validate message content
            is_valid, error_message = validate_message_content(message)
            if not is_valid:
                await interaction.response.send_message(
                    embed=create_error_embed(error_message),
                    ephemeral=True
                )
                return
            
            # Sanitize message
            sanitized_message = sanitize_message(message)
            
            # Log the command usage
            logger.info(f"Say command used by {interaction.user} in {interaction.guild}: {sanitized_message[:50]}...")
            
            # Send the message immediately
            await interaction.response.send_message(sanitized_message)
            
        except discord.NotFound:
            logger.warning(f"Say command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"Say command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in say command: {e}")
        except Exception as e:
            logger.error(f"Error in say command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while processing your request."),
                        ephemeral=True
                    )
            except:
                pass  # If we can't respond, just log it
    
    @app_commands.command(name="embed", description="Create a custom embed")
    @app_commands.describe(
        title="The title of the embed",
        description="The description of the embed",
        color="The color of the embed (hex, name, or rgb)"
    )
    @app_commands.checks.cooldown(BotConfig.MAX_USES_PER_COOLDOWN, BotConfig.EMBED_COOLDOWN)
    async def embed_command(self, interaction: discord.Interaction, title: str, description: str, color: Optional[str] = None):
        """
        Embed command - creates custom embeds
        
        Args:
            interaction: Discord interaction object
            title: Embed title
            description: Embed description
            color: Embed color (optional)
        """
        try:
            # Validate embed content
            is_valid, error_message = validate_embed_content(title, description)
            if not is_valid:
                await interaction.response.send_message(
                    embed=create_error_embed(error_message),
                    ephemeral=True
                )
                return
            
            # Sanitize content
            title = sanitize_message(title)
            description = sanitize_message(description)
            
            # Create embed
            embed = create_embed(title, description, color, interaction.user)
            
            # Log the command usage
            logger.info(f"Embed command used by {interaction.user} in {interaction.guild}: {title}")
            
            # Send the embed immediately
            await interaction.response.send_message(embed=embed)
            
        except discord.NotFound:
            logger.warning(f"Embed command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"Embed command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in embed command: {e}")
        except Exception as e:
            logger.error(f"Error in embed command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while creating the embed."),
                        ephemeral=True
                    )
            except:
                pass  # If we can't respond, just log it
    
    @app_commands.command(name="dm", description="Send a direct message to a user")
    @app_commands.describe(
        user="The user to send the message to (mention, ID, or username)",
        message="The message to send"
    )
    @app_commands.checks.cooldown(BotConfig.MAX_USES_PER_COOLDOWN, BotConfig.DM_COOLDOWN)
    async def dm_command(self, interaction: discord.Interaction, user: str, message: str):
        """
        DM command - sends direct messages to users
        
        Args:
            interaction: Discord interaction object
            user: User to send message to
            message: Message to send
        """
        try:
            # Validate message content
            is_valid, error_message = validate_message_content(message)
            if not is_valid:
                await interaction.response.send_message(
                    embed=create_error_embed(error_message),
                    ephemeral=True
                )
                return
            
            # Check if guild exists
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            # Validate and get target user
            guild = interaction.guild
            target_member, error_message = validate_mention_input(user, guild)
            if not target_member:
                await interaction.response.send_message(
                    embed=create_error_embed(error_message),
                    ephemeral=True
                )
                return
            
            # Check if user can receive DMs
            if not can_dm_user(target_member):
                await interaction.response.send_message(
                    embed=create_error_embed("Cannot send DM to this user (likely a bot)."),
                    ephemeral=True
                )
                return
            
            # Check if user is trying to DM themselves
            if target_member.id == interaction.user.id:
                await interaction.response.send_message(
                    embed=create_error_embed("You cannot send a DM to yourself."),
                    ephemeral=True
                )
                return
            
            # Sanitize message
            sanitized_message = sanitize_message(message)
            
            # Create DM embed with sender info
            dm_embed = discord.Embed(
                title="📬 Direct Message",
                description=sanitized_message,
                color=BotConfig.DEFAULT_EMBED_COLOR
            )
            dm_embed.set_footer(
                text=f"Sent from {guild.name} by {interaction.user.display_name}",
                icon_url=interaction.user.display_avatar.url
            )
            
            # Try to send DM
            try:
                await target_member.send(embed=dm_embed)
                
                # Log the command usage
                logger.info(f"DM sent by {interaction.user} to {target_member} in {interaction.guild}")
                
                # Confirm success
                await interaction.response.send_message(
                    embed=create_success_embed(f"Successfully sent DM to {target_member.mention}"),
                    ephemeral=True
                )
                
            except discord.Forbidden:
                await interaction.response.send_message(
                    embed=create_error_embed("Could not send DM to this user. They may have DMs disabled."),
                    ephemeral=True
                )
            except discord.HTTPException as e:
                logger.error(f"HTTP error sending DM: {e}")
                await interaction.response.send_message(
                    embed=create_error_embed("Failed to send DM due to a Discord API error."),
                    ephemeral=True
                )
                
        except discord.NotFound:
            logger.warning(f"DM command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"DM command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in DM command: {e}")
        except Exception as e:
            logger.error(f"Error in dm command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while processing your request."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="help", description="Get help with bot commands")
    async def help_command(self, interaction: discord.Interaction):
        """
        Help command - shows available commands and their usage
        
        Args:
            interaction: Discord interaction object
        """
        try:
            embed = discord.Embed(
                title="🤖 Bot Commands Help",
                description="Here are all the available commands:",
                color=BotConfig.DEFAULT_EMBED_COLOR
            )
            
            embed.add_field(
                name="📢 `/say [message]`",
                value="Make the bot repeat any message you want",
                inline=False
            )
            
            embed.add_field(
                name="📝 `/embed [title] [description] [color]`",
                value="Create custom embeds with optional colors\n*Colors: hex (#FF0000), names (red, blue), or leave blank*",
                inline=False
            )
            
            embed.add_field(
                name="📬 `/dm [user] [message]`",
                value="Send a direct message to any user\n*User can be @mention, ID, or username*",
                inline=False
            )
            
            embed.add_field(
                name="ℹ️ `/serverinfo`",
                value="Get information about the current server",
                inline=False
            )
            
            embed.add_field(
                name="👤 `/userinfo [user]`",
                value="Get information about a user (leave blank for yourself)",
                inline=False
            )
            
            embed.add_field(
                name="🏓 `/ping`",
                value="Check bot latency and response time",
                inline=False
            )
            
            embed.add_field(
                name="🛡️ **Role Management**",
                value="Commands for managing protected roles",
                inline=False
            )
            
            embed.add_field(
                name="🔒 `/protect-role [role]`",
                value="Make a role protected (only assignable via bot)",
                inline=False
            )
            
            embed.add_field(
                name="👤 `/assign-role [user] [role]`",
                value="Assign a protected role to a user",
                inline=False
            )
            
            embed.add_field(
                name="🔓 `/unprotect-role [role]`",
                value="Remove protection from a role",
                inline=False
            )
            
            embed.add_field(
                name="📋 `/list-protected-roles`",
                value="List all protected roles in this server",
                inline=False
            )
            
            embed.add_field(
                name="❓ `/help`",
                value="Show this help message",
                inline=False
            )
            
            embed.set_footer(text="All commands have cooldowns to prevent spam")
            
            logger.info(f"Help command used by {interaction.user}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except discord.NotFound:
            logger.warning(f"Help command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"Help command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in help command: {e}")
        except Exception as e:
            logger.error(f"Error in help command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while showing help."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="serverinfo", description="Get information about the current server")
    async def serverinfo_command(self, interaction: discord.Interaction):
        """
        Server info command - shows server information
        
        Args:
            interaction: Discord interaction object
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            guild = interaction.guild
            
            embed = discord.Embed(
                title=f"🏰 {guild.name}",
                color=BotConfig.DEFAULT_EMBED_COLOR
            )
            
            if guild.icon:
                embed.set_thumbnail(url=guild.icon.url)
            
            embed.add_field(
                name="📊 Server Stats",
                value=f"**Members:** {guild.member_count}\n"
                      f"**Text Channels:** {len(guild.text_channels)}\n"
                      f"**Voice Channels:** {len(guild.voice_channels)}\n"
                      f"**Roles:** {len(guild.roles)}",
                inline=True
            )
            
            embed.add_field(
                name="👑 Owner",
                value=f"{guild.owner.mention if guild.owner else 'Unknown'}",
                inline=True
            )
            
            embed.add_field(
                name="📅 Created",
                value=guild.created_at.strftime("%B %d, %Y"),
                inline=True
            )
            
            embed.add_field(
                name="🔒 Verification Level",
                value=str(guild.verification_level).replace('_', ' ').title(),
                inline=True
            )
            
            embed.add_field(
                name="🔞 NSFW Filter",
                value=str(guild.explicit_content_filter).replace('_', ' ').title(),
                inline=True
            )
            
            embed.add_field(
                name="🆔 Server ID",
                value=str(guild.id),
                inline=True
            )
            
            if guild.description:
                embed.add_field(
                    name="📋 Description",
                    value=guild.description,
                    inline=False
                )
            
            logger.info(f"Server info command used by {interaction.user} in {guild.name}")
            await interaction.response.send_message(embed=embed)
            
        except discord.NotFound:
            logger.warning(f"Server info command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"Server info command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in server info command: {e}")
        except Exception as e:
            logger.error(f"Error in server info command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while getting server info."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="userinfo", description="Get information about a user")
    @app_commands.describe(user="The user to get info about (leave blank for yourself)")
    async def userinfo_command(self, interaction: discord.Interaction, user: Optional[str] = None):
        """
        User info command - shows user information
        
        Args:
            interaction: Discord interaction object
            user: User to get info about (optional)
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            guild = interaction.guild
            
            # Determine target user
            if user:
                target_member, error_message = validate_mention_input(user, guild)
                if not target_member:
                    await interaction.response.send_message(
                        embed=create_error_embed(error_message),
                        ephemeral=True
                    )
                    return
            else:
                # Get the member object for the interaction user
                target_member = guild.get_member(interaction.user.id)
                if not target_member:
                    await interaction.response.send_message(
                        embed=create_error_embed("Could not find your member information."),
                        ephemeral=True
                    )
                    return
            
            embed = discord.Embed(
                title=f"👤 {target_member.display_name}",
                color=BotConfig.DEFAULT_EMBED_COLOR
            )
            
            embed.set_thumbnail(url=target_member.display_avatar.url)
            
            embed.add_field(
                name="📛 Username",
                value=f"{target_member.name}",
                inline=True
            )
            
            embed.add_field(
                name="🏷️ Nickname",
                value=target_member.nick if target_member.nick else "None",
                inline=True
            )
            
            embed.add_field(
                name="🆔 User ID",
                value=str(target_member.id),
                inline=True
            )
            
            embed.add_field(
                name="📅 Account Created",
                value=target_member.created_at.strftime("%B %d, %Y"),
                inline=True
            )
            
            embed.add_field(
                name="📥 Joined Server",
                value=target_member.joined_at.strftime("%B %d, %Y") if target_member.joined_at else "Unknown",
                inline=True
            )
            
            embed.add_field(
                name="🤖 Bot",
                value="Yes" if target_member.bot else "No",
                inline=True
            )
            
            # Get top roles (excluding @everyone)
            top_roles = [role.mention for role in target_member.roles[1:]][:5]
            if top_roles:
                embed.add_field(
                    name="🎭 Top Roles",
                    value=", ".join(top_roles),
                    inline=False
                )
            
            logger.info(f"User info command used by {interaction.user} for {target_member}")
            await interaction.response.send_message(embed=embed)
            
        except discord.NotFound:
            logger.warning(f"User info command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"User info command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in user info command: {e}")
        except Exception as e:
            logger.error(f"Error in user info command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while getting user info."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="ping", description="Check if the bot is responsive")
    async def ping_command(self, interaction: discord.Interaction):
        """
        Ping command - shows bot latency and response time
        
        Args:
            interaction: Discord interaction object
        """
        try:
            latency = round(self.bot.latency * 1000)
            
            embed = discord.Embed(
                title="🏓 Pong!",
                description=f"Bot latency: **{latency}ms**",
                color=BotConfig.SUCCESS_COLOR
            )
            
            embed.add_field(
                name="📡 Status",
                value="Bot is online and responding!",
                inline=False
            )
            
            logger.info(f"Ping command used by {interaction.user}")
            await interaction.response.send_message(embed=embed)
            
        except discord.NotFound:
            logger.warning(f"Ping command interaction expired for {interaction.user}")
        except discord.HTTPException as e:
            if "already been acknowledged" in str(e):
                logger.warning(f"Ping command already acknowledged for {interaction.user}")
            else:
                logger.error(f"HTTP error in ping command: {e}")
        except Exception as e:
            logger.error(f"Error in ping command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while pinging."),
                        ephemeral=True
                    )
            except:
                pass
    
    @say_command.error
    async def say_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        """Error handler for say command"""
        if isinstance(error, app_commands.CommandOnCooldown):
            await interaction.response.send_message(
                embed=create_error_embed(f"Command is on cooldown. Try again in {error.retry_after:.1f} seconds."),
                ephemeral=True
            )
        else:
            logger.error(f"Say command error: {error}")
    
    @embed_command.error
    async def embed_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        """Error handler for embed command"""
        if isinstance(error, app_commands.CommandOnCooldown):
            await interaction.response.send_message(
                embed=create_error_embed(f"Command is on cooldown. Try again in {error.retry_after:.1f} seconds."),
                ephemeral=True
            )
        else:
            logger.error(f"Embed command error: {error}")
    
    @dm_command.error
    async def dm_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        """Error handler for dm command"""
        if isinstance(error, app_commands.CommandOnCooldown):
            await interaction.response.send_message(
                embed=create_error_embed(f"Command is on cooldown. Try again in {error.retry_after:.1f} seconds."),
                ephemeral=True
            )
        else:
            logger.error(f"DM command error: {error}")

async def setup(bot):
    """Setup function for the cog"""
    await bot.add_cog(GeneralCommands(bot))
