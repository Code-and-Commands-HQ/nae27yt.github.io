"""
Role Management Cog
Contains role assignment and protection commands for the Discord bot
"""

import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os
from typing import Optional
from bot_config import BotConfig
from utils.embed_utils import create_embed, create_error_embed, create_success_embed, create_warning_embed
from utils.validation import validate_message_content, sanitize_message

logger = logging.getLogger(__name__)

class RoleManagement(commands.Cog):
    """Role management cog with protected role assignment"""
    
    def __init__(self, bot):
        self.bot = bot
        self.protected_roles_file = BotConfig.ROLE_ASSIGNMENT_FILE
        self.load_protected_roles()
    
    def load_protected_roles(self):
        """Load protected roles from file"""
        try:
            with open(self.protected_roles_file, 'r') as f:
                self.protected_roles = json.load(f)
        except FileNotFoundError:
            self.protected_roles = {}
            self.save_protected_roles()
    
    def save_protected_roles(self):
        """Save protected roles to file"""
        with open(self.protected_roles_file, 'w') as f:
            json.dump(self.protected_roles, f, indent=2)
    
    @app_commands.command(name="assign-role", description="Assign a protected role to a user")
    @app_commands.describe(
        user="The user to assign the role to",
        role="The role to assign"
    )
    async def assign_role_command(self, interaction: discord.Interaction, user: discord.Member, role: discord.Role):
        """
        Assign role command - assigns protected roles to users
        
        Args:
            interaction: Discord interaction object
            user: User to assign role to
            role: Role to assign
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            guild_id = str(interaction.guild.id)
            role_id = str(role.id)
            
            # Check if role is protected
            if guild_id not in self.protected_roles or role_id not in self.protected_roles[guild_id]:
                await interaction.response.send_message(
                    embed=create_error_embed(f"The role **{role.name}** is not a protected role. Use normal Discord role assignment."),
                    ephemeral=True
                )
                return
            
            # Check if user has permission to assign this role
            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.manage_roles:
                await interaction.response.send_message(
                    embed=create_error_embed("You don't have permission to assign roles."),
                    ephemeral=True
                )
                return
            
            # Check if bot can assign this role
            bot_member = interaction.guild.get_member(self.bot.user.id)
            if not bot_member or role >= bot_member.top_role:
                await interaction.response.send_message(
                    embed=create_error_embed("I don't have permission to assign this role (role is higher than my highest role)."),
                    ephemeral=True
                )
                return
            
            # Check if user already has the role
            if role in user.roles:
                await interaction.response.send_message(
                    embed=create_warning_embed(f"**{user.display_name}** already has the role **{role.name}**."),
                    ephemeral=True
                )
                return
            
            # Assign the role
            await user.add_roles(role, reason=f"Role assigned by {interaction.user} via /assign-role command")
            
            # Log the assignment
            logger.info(f"Protected role {role.name} assigned to {user} by {interaction.user} in {interaction.guild}")
            
            # Send confirmation
            embed = create_success_embed(f"Successfully assigned the role **{role.name}** to **{user.display_name}**.")
            await interaction.response.send_message(embed=embed)
            
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_error_embed("I don't have permission to assign roles."),
                ephemeral=True
            )
        except discord.HTTPException as e:
            logger.error(f"HTTP error in assign role command: {e}")
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    embed=create_error_embed("Failed to assign role due to a Discord API error."),
                    ephemeral=True
                )
            else:
                await interaction.followup.send(
                    embed=create_error_embed("Failed to assign role due to a Discord API error."),
                    ephemeral=True
                )
        except Exception as e:
            logger.error(f"Error in assign role command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while assigning the role."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="protect-role", description="Make a role protected (can only be assigned via bot)")
    @app_commands.describe(role="The role to protect")
    async def protect_role_command(self, interaction: discord.Interaction, role: discord.Role):
        """
        Protect role command - adds a role to the protected list
        
        Args:
            interaction: Discord interaction object
            role: Role to protect
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            # Check permissions
            if not interaction.user.guild_permissions.manage_roles:
                await interaction.response.send_message(
                    embed=create_error_embed("You need 'Manage Roles' permission to use this command."),
                    ephemeral=True
                )
                return
            
            guild_id = str(interaction.guild.id)
            role_id = str(role.id)
            
            # Initialize guild in protected roles if not exists
            if guild_id not in self.protected_roles:
                self.protected_roles[guild_id] = {}
            
            # Check if role is already protected
            if role_id in self.protected_roles[guild_id]:
                await interaction.response.send_message(
                    embed=create_warning_embed(f"The role **{role.name}** is already protected."),
                    ephemeral=True
                )
                return
            
            # Add role to protected list
            self.protected_roles[guild_id][role_id] = {
                "name": role.name,
                "protected_by": interaction.user.id,
                "protected_at": discord.utils.utcnow().isoformat()
            }
            self.save_protected_roles()
            
            logger.info(f"Role {role.name} protected by {interaction.user} in {interaction.guild}")
            
            # Send confirmation
            embed = create_success_embed(
                f"The role **{role.name}** is now protected.\n\n"
                f"• Can only be assigned using `/assign-role`\n"
                f"• Will be automatically removed if added manually"
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error in protect role command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while protecting the role."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="unprotect-role", description="Remove protection from a role")
    @app_commands.describe(role="The role to unprotect")
    async def unprotect_role_command(self, interaction: discord.Interaction, role: discord.Role):
        """
        Unprotect role command - removes a role from the protected list
        
        Args:
            interaction: Discord interaction object
            role: Role to unprotect
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            # Check permissions
            if not interaction.user.guild_permissions.manage_roles:
                await interaction.response.send_message(
                    embed=create_error_embed("You need 'Manage Roles' permission to use this command."),
                    ephemeral=True
                )
                return
            
            guild_id = str(interaction.guild.id)
            role_id = str(role.id)
            
            # Check if role is protected
            if guild_id not in self.protected_roles or role_id not in self.protected_roles[guild_id]:
                await interaction.response.send_message(
                    embed=create_error_embed(f"The role **{role.name}** is not currently protected."),
                    ephemeral=True
                )
                return
            
            # Remove role from protected list
            del self.protected_roles[guild_id][role_id]
            self.save_protected_roles()
            
            logger.info(f"Role {role.name} unprotected by {interaction.user} in {interaction.guild}")
            
            # Send confirmation
            embed = create_success_embed(f"The role **{role.name}** is no longer protected and can be assigned normally.")
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error in unprotect role command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while unprotecting the role."),
                        ephemeral=True
                    )
            except:
                pass
    
    @app_commands.command(name="list-protected-roles", description="List all protected roles in this server")
    async def list_protected_roles_command(self, interaction: discord.Interaction):
        """
        List protected roles command - shows all protected roles
        
        Args:
            interaction: Discord interaction object
        """
        try:
            if not interaction.guild:
                await interaction.response.send_message(
                    embed=create_error_embed("This command can only be used in a server."),
                    ephemeral=True
                )
                return
            
            guild_id = str(interaction.guild.id)
            
            if guild_id not in self.protected_roles or not self.protected_roles[guild_id]:
                await interaction.response.send_message(
                    embed=create_error_embed("No protected roles are set up in this server."),
                    ephemeral=True
                )
                return
            
            # Build list of protected roles
            role_list = []
            for role_id, role_data in self.protected_roles[guild_id].items():
                role = interaction.guild.get_role(int(role_id))
                if role:
                    protected_by = interaction.guild.get_member(role_data.get('protected_by', 0))
                    protected_by_name = protected_by.display_name if protected_by else "Unknown"
                    role_list.append(f"• **{role.name}** (protected by {protected_by_name})")
                else:
                    # Role no longer exists, remove from protected list
                    role_list.append(f"• **{role_data['name']}** *(role deleted)*")
            
            embed = discord.Embed(
                title="🛡️ Protected Roles",
                description="\n".join(role_list) if role_list else "No protected roles found.",
                color=BotConfig.DEFAULT_EMBED_COLOR
            )
            embed.set_footer(text="These roles can only be assigned using /assign-role")
            
            logger.info(f"Protected roles list viewed by {interaction.user} in {interaction.guild}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in list protected roles command: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        embed=create_error_embed("An error occurred while listing protected roles."),
                        ephemeral=True
                    )
            except:
                pass
    
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """
        Event listener for member updates (role changes)
        Removes protected roles if they were added manually
        """
        try:
            # Check if roles were added
            added_roles = set(after.roles) - set(before.roles)
            if not added_roles:
                return
            
            guild_id = str(after.guild.id)
            if guild_id not in self.protected_roles:
                return
            
            # Check if any added roles are protected
            for role in added_roles:
                role_id = str(role.id)
                if role_id in self.protected_roles[guild_id]:
                    # Check if this was done through the bot (check audit log)
                    try:
                        # Get recent audit log entries for role updates
                        async for entry in after.guild.audit_logs(
                            action=discord.AuditLogAction.member_role_update,
                            limit=5
                        ):
                            # If the bot made this change, skip removal
                            if entry.user == self.bot.user and entry.target == after:
                                return
                        
                        # If we get here, the role was added manually - remove it
                        await after.remove_roles(role, reason="Protected role added manually - removing")
                        
                        logger.warning(
                            f"Removed protected role {role.name} from {after} "
                            f"(was added manually in {after.guild})"
                        )
                        
                        # Try to DM the user about the removal
                        try:
                            embed = create_warning_embed(
                                f"The role **{role.name}** was removed from you in **{after.guild.name}** "
                                f"because it's a protected role that can only be assigned by server moderators "
                                f"using the `/assign-role` command."
                            )
                            await after.send(embed=embed)
                        except discord.Forbidden:
                            # User has DMs disabled
                            pass
                            
                    except discord.Forbidden:
                        logger.warning(f"Cannot remove protected role {role.name} - insufficient permissions")
                    except Exception as e:
                        logger.error(f"Error handling protected role removal: {e}")
        
        except Exception as e:
            logger.error(f"Error in on_member_update event: {e}")

async def setup(bot):
    """Setup function for the cog"""
    await bot.add_cog(RoleManagement(bot))