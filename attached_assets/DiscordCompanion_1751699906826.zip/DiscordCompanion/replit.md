# Discord Bot with Slash Commands

## Overview

This is a Discord bot built with Python and discord.py that provides three main slash commands: `/say` (message echoing), `/embed` (custom embed creation), and `/dm` (direct messaging). The bot is designed with a modular architecture featuring proper configuration management, utility functions, and comprehensive validation.

## System Architecture

The application follows a modular monolithic architecture with clear separation of concerns:

**Core Components:**
- `main.py`: Entry point and bot initialization
- `bot_config.py`: Centralized configuration management
- `cogs/`: Command organization using discord.py's cog system
- `utils/`: Shared utility functions for validation and embed creation

**Design Patterns:**
- **Cog Pattern**: Commands are organized into separate cogs for better maintainability
- **Configuration Class**: All settings centralized in BotConfig class
- **Utility Functions**: Reusable validation and embed creation functions

## Key Components

### Bot Core (`main.py`)
- **Purpose**: Main bot initialization and event handling
- **Architecture**: Custom DiscordBot class extending commands.Bot
- **Features**: Logging setup, cog loading, and slash command synchronization

### Configuration (`bot_config.py`)
- **Purpose**: Centralized configuration management
- **Architecture**: Static configuration class with environment variable support
- **Settings**: Cooldowns, rate limiting, embed limits, permissions, and styling

### Command System (`cogs/general_commands.py`)
- **Purpose**: Slash command implementations
- **Architecture**: Cog-based command organization
- **Core Commands**: 
  - `/say`: Message echoing with validation
  - `/embed`: Custom embed creation
  - `/dm`: Direct messaging functionality
- **Utility Commands**:
  - `/help`: Interactive help system with command descriptions
  - `/ping`: Bot latency and response time checking
  - `/serverinfo`: Detailed server information display
  - `/userinfo`: User profile information with roles and stats
- **Role Management Commands**:
  - `/protect-role`: Mark roles as protected (only bot-assignable)
  - `/assign-role`: Assign protected roles to users safely
  - `/unprotect-role`: Remove role protection
  - `/list-protected-roles`: View all protected roles in server

### Utilities
- **`embed_utils.py`**: Embed creation, validation, and color parsing
- **`validation.py`**: Input validation and permission checking

## Data Flow

1. **Command Execution**: User triggers slash command → Discord API → Bot receives interaction
2. **Validation**: Input validation → Permission checks → Content sanitization
3. **Processing**: Command logic execution → Response generation
4. **Response**: Formatted response → Discord API → User sees result

**Error Handling**: Comprehensive validation with user-friendly error messages sent as ephemeral responses.

## External Dependencies

### Required Packages
- `discord.py`: Discord API wrapper and bot framework
- `python-dotenv`: Environment variable management

### Discord API Integration
- **Slash Commands**: Modern Discord command interface
- **Intents**: Message content, guild, and member intents
- **Permissions**: Send messages, embed links, read history, use slash commands

## Deployment Strategy

### Environment Setup
- Python 3.8+ required
- Discord bot token via environment variable `DISCORD_BOT_TOKEN`
- Logging to both file (`bot.log`) and console

### Configuration Management
- Environment-based configuration with defaults
- Centralized settings in BotConfig class
- Configurable cooldowns, rate limits, and permissions

### Scalability Considerations
- Modular cog system for easy feature addition
- Separate utility modules for code reuse
- Comprehensive logging for monitoring

## Changelog
- July 05, 2025: Initial setup with core commands (`/say`, `/embed`, `/dm`)
- July 05, 2025: Added utility commands (`/help`, `/ping`, `/serverinfo`, `/userinfo`)
- July 05, 2025: Enhanced error handling and interaction timeout management
- July 05, 2025: Added role management system with protected role assignments and automatic enforcement

## User Preferences

Preferred communication style: Simple, everyday language.