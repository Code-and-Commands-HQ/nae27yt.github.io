"""
Embed Utilities
Helper functions for creating and validating Discord embeds
"""

import discord
import re
from typing import Optional, Tuple
from bot_config import BotConfig

def parse_color(color_input: str) -> int:
    """
    Parse color input and return Discord color integer
    
    Args:
        color_input: Color string (hex, name, or rgb)
        
    Returns:
        Discord color integer
    """
    color_input = color_input.strip().lower()
    
    # Hex color
    if color_input.startswith('#'):
        try:
            return int(color_input[1:], 16)
        except ValueError:
            return BotConfig.DEFAULT_EMBED_COLOR
    
    # Named colors
    color_map = {
        'red': 0xff0000,
        'green': 0x00ff00,
        'blue': 0x0000ff,
        'yellow': 0xffff00,
        'purple': 0x800080,
        'orange': 0xffa500,
        'pink': 0xffc0cb,
        'cyan': 0x00ffff,
        'black': 0x000000,
        'white': 0xffffff,
        'gray': 0x808080,
        'grey': 0x808080,
        'discord': BotConfig.DEFAULT_EMBED_COLOR,
        'blurple': BotConfig.DEFAULT_EMBED_COLOR
    }
    
    if color_input in color_map:
        return color_map[color_input]
    
    # Try to parse as hex without #
    try:
        return int(color_input, 16)
    except ValueError:
        return BotConfig.DEFAULT_EMBED_COLOR

def validate_embed_content(title: str, description: str) -> Tuple[bool, str]:
    """
    Validate embed content for length and format
    
    Args:
        title: Embed title
        description: Embed description
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if len(title) > BotConfig.MAX_EMBED_TITLE_LENGTH:
        return False, f"Title too long (max {BotConfig.MAX_EMBED_TITLE_LENGTH} characters)"
    
    if len(description) > BotConfig.MAX_EMBED_DESCRIPTION_LENGTH:
        return False, f"Description too long (max {BotConfig.MAX_EMBED_DESCRIPTION_LENGTH} characters)"
    
    if not title.strip():
        return False, "Title cannot be empty"
    
    return True, ""

def create_embed(title: str, description: str, color: Optional[str] = None, 
                author: Optional[discord.abc.User] = None) -> discord.Embed:
    """
    Create a Discord embed with the specified parameters
    
    Args:
        title: Embed title
        description: Embed description
        color: Color string (optional)
        author: User who created the embed (optional)
        
    Returns:
        Discord embed object
    """
    embed_color = parse_color(color) if color else BotConfig.DEFAULT_EMBED_COLOR
    
    embed = discord.Embed(
        title=title,
        description=description,
        color=embed_color
    )
    
    if author:
        embed.set_footer(
            text=f"Created by {author.display_name}",
            icon_url=author.display_avatar.url
        )
    
    return embed

def create_error_embed(message: str) -> discord.Embed:
    """
    Create an error embed
    
    Args:
        message: Error message
        
    Returns:
        Discord error embed
    """
    return discord.Embed(
        title="❌ Error",
        description=message,
        color=BotConfig.ERROR_COLOR
    )

def create_success_embed(message: str) -> discord.Embed:
    """
    Create a success embed
    
    Args:
        message: Success message
        
    Returns:
        Discord success embed
    """
    return discord.Embed(
        title="✅ Success",
        description=message,
        color=BotConfig.SUCCESS_COLOR
    )

def create_warning_embed(message: str) -> discord.Embed:
    """
    Create a warning embed
    
    Args:
        message: Warning message
        
    Returns:
        Discord warning embed
    """
    return discord.Embed(
        title="⚠️ Warning",
        description=message,
        color=BotConfig.WARNING_COLOR
    )
