"""
Validation Utilities
Helper functions for validating user input and permissions
"""

import discord
from typing import Optional, Tuple
from bot_config import BotConfig

def validate_message_content(content: str) -> Tuple[bool, str]:
    """
    Validate message content for length and format
    
    Args:
        content: Message content to validate
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not content.strip():
        return False, "Message cannot be empty"
    
    if len(content) > BotConfig.MAX_MESSAGE_LENGTH:
        return False, f"Message too long (max {BotConfig.MAX_MESSAGE_LENGTH} characters)"
    
    return True, ""

def validate_user_permissions(user: discord.Member, required_permissions: list) -> Tuple[bool, str]:
    """
    Validate if user has required permissions
    
    Args:
        user: Discord member to check
        required_permissions: List of required permission names
        
    Returns:
        Tuple of (has_permissions, missing_permissions)
    """
    if not user.guild_permissions:
        return False, "Unable to check permissions"
    
    missing_permissions = []
    
    for perm in required_permissions:
        if not getattr(user.guild_permissions, perm, False):
            missing_permissions.append(perm)
    
    if missing_permissions:
        return False, f"Missing permissions: {', '.join(missing_permissions)}"
    
    return True, ""

def validate_bot_permissions(bot_member: discord.Member, channel: discord.TextChannel) -> Tuple[bool, str]:
    """
    Validate if bot has required permissions in a channel
    
    Args:
        bot_member: Bot's member object
        channel: Channel to check permissions for
        
    Returns:
        Tuple of (has_permissions, missing_permissions)
    """
    permissions = channel.permissions_for(bot_member)
    
    missing_permissions = []
    
    if not permissions.send_messages:
        missing_permissions.append("send_messages")
    
    if not permissions.embed_links:
        missing_permissions.append("embed_links")
    
    if not permissions.read_message_history:
        missing_permissions.append("read_message_history")
    
    if missing_permissions:
        return False, f"Bot missing permissions: {', '.join(missing_permissions)}"
    
    return True, ""

def can_dm_user(user: discord.abc.User) -> bool:
    """
    Check if user can receive DMs
    
    Args:
        user: Discord user to check
        
    Returns:
        Boolean indicating if user can receive DMs
    """
    # We can't definitively check this without trying to send a DM
    # This is a basic check - bots can't DM other bots
    return not user.bot

def sanitize_message(message: str) -> str:
    """
    Sanitize message content to prevent potential issues
    
    Args:
        message: Message to sanitize
        
    Returns:
        Sanitized message
    """
    # Remove @everyone and @here mentions
    message = message.replace('@everyone', '@\u200beveryone')
    message = message.replace('@here', '@\u200bhere')
    
    # Limit consecutive newlines
    import re
    message = re.sub(r'\n{4,}', '\n\n\n', message)
    
    return message.strip()

def validate_mention_input(mention_input: str, guild: discord.Guild) -> Tuple[Optional[discord.Member], str]:
    """
    Validate and parse user mention input
    
    Args:
        mention_input: User mention or ID string
        guild: Guild to search for member
        
    Returns:
        Tuple of (member, error_message)
    """
    # Try to parse mention
    import re
    
    # Check for mention format <@!123456789> or <@123456789>
    mention_match = re.match(r'<@!?(\d+)>', mention_input)
    if mention_match:
        user_id = int(mention_match.group(1))
        member = guild.get_member(user_id)
        if member:
            return member, ""
        else:
            return None, "User not found in this server"
    
    # Try to parse as user ID
    try:
        user_id = int(mention_input)
        member = guild.get_member(user_id)
        if member:
            return member, ""
        else:
            return None, "User not found in this server"
    except ValueError:
        pass
    
    # Try to find by username
    member = discord.utils.find(
        lambda m: m.name.lower() == mention_input.lower() or 
                 m.display_name.lower() == mention_input.lower(),
        guild.members
    )
    
    if member:
        return member, ""
    
    return None, "User not found. Please use a mention, user ID, or exact username"
